# Canon

Ce fichier tient ce qui ne doit pas changer.
Le trigger porte l’identité. Les légendes, dans `dataset/`, disent ce qui peut varier.

## Trigger

``

## Invariants

-
-

## Note

Une ligne, si quelque chose doit rester hors des légendes.
