# U*TTU Studio — coffre

Ce dossier est le studio. Le site est la surface. Ici, les fichiers restent.

## Ouvrir dans Obsidian

1. Garde ce dossier tel quel, nommé `U-TTU-Studio`.
2. Obsidian → ouvrir un dossier comme coffre → ce dossier.
3. Aucun plugin n’est requis.

## Pièces

- `refs/` — photos sources, deux ou trois.
- `dataset/` — le lot de quinze, et les légendes `.txt`.
- `loras/` — fichiers `.safetensors`, et une note.
- `scenes/` — avant, après, entre.
- `processes/` — recettes, liens, prompts.
- `jobs.md` — le journal.
- `CANON.md` — trigger et invariants.

Hors ligne, aujourd’hui. Un compte pourra synchroniser plus tard. La vente reste en HOLD.
