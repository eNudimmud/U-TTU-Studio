# Travaux

Journal local. Une ligne par geste. Rien ne quitte la machine.

| Date | Geste | Dossier | Note |
| --- | --- | --- | --- |
|  |  |  |  |

## Modèle

À effacer. Ceci n’est pas un run.

| Date | Geste | Dossier | Note |
| --- | --- | --- | --- |
| 2026-09-28 | Lot rangé | dataset/ | Quinze images, légendes à côté |
| 2026-09-28 | LoRA déposée | loras/ | Fichier .safetensors, note de force à côté |
